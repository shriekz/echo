from __future__ import print_function
import weather

#print("Hello")
#print("Awesome" + weather.getWeather())

fullstring = ["I Std C (2017)", "V Std C (2017)"]

v = "V Std C"

if v in fullstring: print ("Success")