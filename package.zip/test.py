from __future__ import print_function
import weather

print("Hello")
print("Awesome" + weather.getWeather())